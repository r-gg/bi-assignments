CREATE TABLE TB_OrderStatus (
	OrderStatusID INT NOT NULL,
	OrderStatusName VARCHAR(50) NOT NULL,
	constraint PK_OrderStatus PRIMARY KEY (OrderStatusID)
);