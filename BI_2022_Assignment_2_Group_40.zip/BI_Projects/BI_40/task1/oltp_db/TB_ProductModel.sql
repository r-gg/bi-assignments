CREATE TABLE TB_ProductModel (
	ProductModelID INT NOT NULL,
	ProductModelName VARCHAR(50) NOT NULL,
	constraint PK_ProductModel PRIMARY KEY (ProductModelID)
);